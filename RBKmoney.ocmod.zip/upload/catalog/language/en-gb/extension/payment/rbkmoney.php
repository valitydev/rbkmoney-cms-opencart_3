<?php
// Text
$_['text_title'] = 'RBKmoney';

?>